    /*
    NAME            : NAGABANDI SUPRIYA
    DATE            : 05-04-2026
    PROJECT         : MINI SHELL IMPLEMENTATION


    DESCRIPTION:
    This project implements a simple command-line shell similar to Linux terminal.

    FEATURES:
    - Displays a custom prompt (MiniShell:$)
    - Accepts and executes user commands

    BUILT-IN COMMANDS:
    - pwd      -> Prints current working directory
    - cd       -> Changes directory
    - echo     -> Prints text and special variables:
                  * $$ → Process ID
                  * $? → Last command exit status
                  * $SHELL → Shell path
    - exit     -> Exits the shell
    - clear    -> Clears the screen

    EXTERNAL COMMANDS:
    - Executes system commands like ls, sleep, etc. using fork and exec.

    JOB CONTROL 
    - Handles foreground and background processes
    - Tracks process IDs and statuses

    WORKING:
    - Reads input from user
    - Identifies command type (built-in or external)
    - Executes the appropriate logic
    - Loops continuously until exit is called
    */

// ===============  MAIN FUNCTION  =================

#include "header.h"

// ===== GLOBAL VARIABLES =====
char prompt[50] = "MiniShell:$ ";   // shell prompt
char input_string[100];             // user input
char buf[100];                     // buffer
int status;                        // status of last process
char *external_commands[800];      // list of external commands
Slist *head = NULL;                // job list head
int job_id = 1; 
// ===== FOREGROUND PROCESS =====
pid_t fg_pid = 0;                  // current foreground process

// ===== MAIN =====
int main()
{
    job_id=1;

    getcwd(buf, sizeof(buf)); // for echo $SHELL

    system("clear");  // clear screen at start

    // handle signals
    signal(SIGINT, signal_handler);  // ctrl + c
    signal(SIGTSTP, signal_handler); // ctrl + Z
    signal(SIGCHLD, signal_handler); //  child finished

    extract_external_commands(external_commands); // load commands

    scan_input(prompt, input_string); // start shell

    return 0;
}

// ===== INSERT JOB AT LAST =====
void insert_at_last(pid_t pid, char *cmd)
{

    Slist *new = malloc(sizeof(Slist)); // create new node
    if (new==NULL)
    {
        perror("error");
        return;
    }

    new->job_id = job_id++;
    new->pid = pid;
    strcpy(new->cmd, cmd);
    new->flag = 1;
    new->link = NULL;

    // insert at end
    if (head == NULL)
    {
        head = new;
    }
    else
    {
        Slist *temp = head;
        while (temp->link)
            temp = temp->link;

        temp->link = new;
    }

}

// ===== SIGNAL HANDLER =====
void signal_handler(int sig_num)
{
    if (sig_num == SIGINT) // Ctrl + C
    {
        if (fg_pid != 0)
        {
            kill(fg_pid, SIGINT); // send signal to process for ctrl + c 
        }
        else
        {
            printf("\n" ANSI_COLOR_GREEN "%s" ANSI_COLOR_RESET, prompt);
            fflush(stdout);
        }
    }
    else if (sig_num == SIGTSTP) // Ctrl + Z
    {
        if (fg_pid != 0)
        {
            kill(fg_pid, SIGTSTP);
        }
        else
        {
            printf("\n" ANSI_COLOR_GREEN "%s" ANSI_COLOR_RESET, prompt);
            fflush(stdout);
        }
    }

    else if (sig_num == SIGCHLD) // child finished
    {
        int stat;
        pid_t pid;

        // finished processes
        while ((pid = waitpid(-1, &stat, WNOHANG)) > 0)
        {
            job_id--;
            
            Slist *temp = head, *prev = NULL;

            while (temp)
            {
                if (temp->pid == pid)
                {
                    if (prev)
                        prev->link = temp->link;
                    else
                        head = temp->link;

                    free(temp);
                    break;
                }
                prev = temp;
                temp = temp->link;
            }
        }
    }
}

// ===== EXTRACT EXTERNAL COMMANDS =====
void extract_external_commands(char **external_commands)
{
    int fd = open("external_cmd.txt", O_RDONLY);
    if (fd < 0)
    {
        perror("open");
        return;
    }

    char ch, temp[50];
    int i = 0, index = 0;

    // read file char by char
    while (read(fd, &ch, 1) > 0)
    {
        if (ch != '\n')
        {
            temp[i++] = ch;
        }
        else
        {
            temp[i] = '\0';
            external_commands[index] = malloc(strlen(temp) + 1);
            strcpy(external_commands[index++], temp);
            i = 0;
        }
    }

    //  to execute the last command
    if (i > 0)
    {
        temp[i] = '\0';
        external_commands[index] = malloc(strlen(temp) + 1);
        strcpy(external_commands[index++], temp);
    }

    external_commands[index] = NULL;

    close(fd);
}

// ===== GET COMMAND =====
char *get_command(char *input_string)
{
    static char cmd[20];
    int i = 0;

    // extract first word
    while (input_string[i] != ' ' && input_string[i] != '\0')
    {
        cmd[i] = input_string[i];
        i++;
    }
    cmd[i] = '\0';

    return cmd;
}

// ===== CHECK TYPE =====
int check_command_type(char *command)
{
    if (strncmp(command, "echo", 4) == 0)
        return BUILTIN;   // treat echo as builtin

    char *internal_cmds[] = {"cd","pwd","exit","clear", NULL};

    // compare with internal commands
    for (int i = 0;internal_cmds[i]; i++)
    {
        if (strcmp(command, internal_cmds[i]) == 0)
            return BUILTIN;
    }

    return EXTERNAL;
}

// ===== INTERNAL COMMANDS =====
void execute_internal_commands(char *input_string)
{
    // ===== EXIT COMMAND =====
    if(strcmp(input_string,"exit")==0)
    {
        exit(0);
    }

    // ===== PWD =====
    else if (strcmp(input_string, "pwd") == 0)
    {
        char buf1[100];
        getcwd(buf1, sizeof(buf1));
        printf(ANSI_COLOR_GREEN "%s\n" ANSI_COLOR_RESET, buf1);
    }

    // ===== CD =====
    else if (strncmp(input_string, "cd ", 3) == 0)
    {
        if (chdir(input_string + 3) != 0)
            perror("cd");
    }

    else if (strncmp(input_string, "echo", 4) == 0)
    {
        char *echo_info = input_string + 4;

        while (*echo_info == ' ')
             echo_info++;  // skip spaces

        if (strcmp(echo_info, "$$") == 0)
            printf("%d\n", getpid());

        else if (strcmp(echo_info, "$?") == 0)
            printf("%d\n", WEXITSTATUS(status));

        else if (strcmp(echo_info, "$SHELL") == 0)
            printf("%s\n", buf);

        else
            printf("%s\n", echo_info);
    }

    else if(strcmp(input_string,"clear")==0)
    {
        system("clear");   
    }

}

// ===== PRINT JOBS =====
void print_list(Slist *head)
{
    if (head == NULL)
    {
        printf(ANSI_COLOR_RED "No jobs\n" ANSI_COLOR_RESET);
        return;
    }

    Slist *temp = head;

    while (temp)
    {
        printf(ANSI_COLOR_GREEN "[%d] ^Z Stopped %s\n" ANSI_COLOR_RESET, temp->job_id, temp->cmd);
        temp = temp->link;
    }
}

// ===== EXECUTE EXTERNAL COMMANDS =====
void execute_external_commands(char *input)
{
    char *commands[10];
    int num_cmds = 0;

    char temp[100];
    strcpy(temp, input);

    char *token = strtok(temp, "|");
    while (token)
    {
        while (*token == ' ') 
            token++; // skip spaces

        commands[num_cmds++] = token;
        token = strtok(NULL, "|");
    }

    // ===== no pipe is present =====
    if (num_cmds == 1)
    {
        char *argv[20];
        int i = 0;

        char temp2[100];
        strcpy(temp2, commands[0]);

        char *tok = strtok(temp2, " ");
        while (tok)
        {
            argv[i] = tok;
            i++;
            tok = strtok(NULL, " ");
        }
        argv[i] = NULL;

        execvp(argv[0], argv);

        printf(ANSI_COLOR_RED "ERROR : WRONG COMMAND USAGE\n"ANSI_COLOR_RESET);
        exit(1);
    }

    // ===== PIPE =====
    int fd[2];
    int prev_fd = 0;

    for (int i = 0; i < num_cmds; i++)
    {
        pipe(fd);

        pid_t pid = fork();

        if (pid == 0)
        {
            if (i > 0)
            {
                dup2(prev_fd, 0); // input from prev
                close(prev_fd);
            }

            if (i < num_cmds - 1)
            {
                dup2(fd[1], 1); // output to next
            }

            close(fd[0]);

            char *argv[20];
            int j = 0;

            char temp2[100];
            strcpy(temp2, commands[i]);

            char *tok = strtok(temp2, " ");
            while (tok)
            {
                argv[j] = tok;
                j++;
                tok = strtok(NULL, " ");
            }
            argv[j] = NULL;

            execvp(argv[0], argv);
            printf(ANSI_COLOR_RED "ERROR : WRONG COMMAND USAGE\n"ANSI_COLOR_RESET);
            exit(1);
        }
        else
        {
            close(fd[1]);

            if (i > 0)
                close(prev_fd);

            prev_fd = fd[0];
        }
    }

    // wait all children
    for (int i = 0; i < num_cmds; i++)
        wait(NULL);
}