  /*
    NAME            : NAGABANDI SUPRIYA
    DATE            : 05-04-2026
    PROJECT         : MINI SHELL IMPLEMENTATION

*/

// ===============  SCAN INPUT FUNCTION  =================

#include "header.h"

// ===== GLOBAL VARIABLES =====
extern char buf[100];      // buffer for path
extern Slist *head;        // job list
extern pid_t fg_pid;       // foreground process id
extern int status;         // last command status

char *word;               // command
int var;                  // command type

// ===== INPUT LOOP =====
void scan_input(char *prompt, char *input_string)
{
    // get current working directory
    if(getcwd(buf,sizeof(buf)) == NULL)
    {
        printf(ANSI_COLOR_RED "Error\n" ANSI_COLOR_RESET);
    }

    printf(ANSI_COLOR_RED"==========================================================================="ANSI_COLOR_RESET);
    printf(ANSI_COLOR_BLUE "\n====================== WELCOME TO MINI SHELL ==============================\n" ANSI_COLOR_RESET);
    printf(ANSI_COLOR_RED"===========================================================================\n"ANSI_COLOR_RESET);

    while (1)
    {
        // print shell prompt
        printf(ANSI_COLOR_YELLOW "%s" ANSI_COLOR_RESET, prompt);
        fflush(stdout);

        input_string[0] = '\0'; // clear input

        // take input from user
        scanf("%[^\n]", input_string);
        getchar();

        // ===== CHANGE PROMPT =====
        if(strncmp(input_string, "PS1=", 4) == 0)
        {
            // check for spaces in prompt
            if (strchr(input_string, ' '))
            {
                printf(ANSI_COLOR_RED "No spaces allowed in PS1\n" ANSI_COLOR_RESET);
            }
            else
            {
                strcpy(prompt, input_string + 4); // update prompt
            }
            continue;
        }

        if (strlen(input_string) == 0)
            continue;

        word = get_command(input_string);        // extract command
        var = check_command_type(word);          // check builtin or external

        // ===== JOBS COMMAND =====
        if(strcmp(input_string, "jobs") == 0)
        {
            printf(ANSI_COLOR_MAGENTA "Listing jobs...\n" ANSI_COLOR_RESET);
            print_list(head); // display jobs
        }

        // ===== FOREGROUND =====
        else if(strcmp(input_string, "fg") == 0)
        {
            if(head == NULL)
            {
                printf(ANSI_COLOR_RED "No jobs\n" ANSI_COLOR_RESET);
                continue;
            }

            Slist *temp = head; // first job

            printf(ANSI_COLOR_BLUE "Running: %s\n" ANSI_COLOR_RESET, temp->cmd);

            kill(temp->pid, SIGCONT); // resume process

            fg_pid = temp->pid; // set foreground

            waitpid(temp->pid, &status, WUNTRACED); // wait

            head = temp->link; // remove from list
            free(temp);

            printf(ANSI_COLOR_GREEN "Job completed\n" ANSI_COLOR_RESET);

            fg_pid = 0; // reset
        }

        // ===== BACKGROUND =====
        else if(strcmp(input_string, "bg") == 0)
        {
            if(head == NULL)
            {
                printf(ANSI_COLOR_RED "No jobs\n" ANSI_COLOR_RESET);
                continue;
            }

            Slist *temp = head; // first job

            printf(ANSI_COLOR_MAGENTA "[%d] %s\n" ANSI_COLOR_RESET, temp->job_id, temp->cmd);

            kill(temp->pid, SIGCONT); // continue in background

            printf(ANSI_COLOR_GREEN "Job running in background\n" ANSI_COLOR_RESET);
        }

        // ===== BUILTIN COMMAND =====
        else if(var == BUILTIN)
        {
            execute_internal_commands(input_string); // execute builtin
        }

        // ===== EXTERNAL COMMAND =====
        else if(var == EXTERNAL)
        {
            pid_t pid = fork(); // create child process

            if(pid > 0)
            {
                fg_pid = pid; // track foreground

                waitpid(pid, &status, WUNTRACED); // wait

                // check if stopped (Ctrl + Z)
                if(WIFSTOPPED(status))
                {
                    insert_at_last(pid, input_string); // add to jobs

                    Slist *temp = head;
                    while(temp->link)
                        temp = temp->link;

                    printf(ANSI_COLOR_MAGENTA "[%d]+ Stopped %s\n" ANSI_COLOR_RESET,
                           temp->job_id, input_string);
                }

                fg_pid = 0; // reset
            }
            else if(pid == 0)
            {
                signal(SIGINT,SIG_DFL);
                signal(SIGTSTP,SIG_DFL);
                execute_external_commands(input_string); // run command
                exit(0);
            }
        }

        // ===== INVALID COMMAND =====
        else
        {
            printf(ANSI_COLOR_RED "Error: Wrong Command Usage\n" ANSI_COLOR_RESET);
        }
    }
}